"""Bucle de entrenamiento y evaluacion de EffPS-Lite (curvas de perdida, mejor modelo, metricas en test)."""
import json
import math
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch
from torch.nn.utils import clip_grad_norm_

from .config import CLASS_NAMES, NUM_CLASSES, OUTPUTS_DIR, WEIGHTS_DIR
from .metrics import InstanceAP, SegMetrics, check_targets


@torch.no_grad()
def evaluate(model, loader, device, threshold=0.5, instancias=False, score_thr=0.5):
    """Evalua en un loader. Devuelve {'overall','per_class'} (+ 'instancias' si instancias=True)."""
    metrics = SegMetrics(threshold=threshold)
    iap = InstanceAP() if instancias else None
    for batch in loader:
        probs, pans = model.predict(batch["image"], panoptic=instancias, score_thr=score_thr)
        metrics.update(probs, batch["gt"])
        if iap is not None:
            for pan, gt_m in zip(pans, batch["inst_masks"]):
                piezas = [s for s in pan["segments"] if s["is_thing"]]
                iap.update([s["mask"] for s in piezas], [s["score"] for s in piezas], gt_m.numpy())
    res = metrics.compute()
    if iap is not None:
        res["instancias"] = iap.compute()
    return res


def _mean(acc, n):
    return {k: v / max(n, 1) for k, v in acc.items()}


def fit(model, loaders, device, epochs=40, lr=1e-4, patience=10, warmup_epochs=1,
        weight_decay=1e-4, tag="effps", weights_path=None, log=print):
    """Entrena y guarda el mejor modelo (mayor mIoU en validacion). Devuelve el historial."""
    weights_path = Path(weights_path or WEIGHTS_DIR / f"{tag}_best.pt")
    weights_path.parent.mkdir(parents=True, exist_ok=True)
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

    opt = torch.optim.AdamW(model.param_groups(lr), weight_decay=weight_decay)
    steps = max(len(loaders["train"]), 1)
    total, warm = epochs * steps, warmup_epochs * steps
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(total - warm, 1))))
    use_amp = bool(model.use_amp and str(device).startswith("cuda"))
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    hist = {"epoch": [], "train_loss": [], "val_loss": [], "val_mIoU": [], "lr": []}
    best, bad = -1.0, 0
    for ep in range(1, epochs + 1):
        t0 = time.time()
        acc, n = {}, 0
        for batch in loaders["train"]:                      # ---- entrenamiento
            with torch.autocast("cuda", dtype=torch.float16, enabled=use_amp):
                losses = model.train_loss(batch)
            opt.zero_grad(set_to_none=True)
            scaler.scale(losses["loss"]).backward()
            scaler.unscale_(opt)
            clip_grad_norm_([p for g in opt.param_groups for p in g["params"]], 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            for k, v in losses.items():
                acc[k] = acc.get(k, 0.0) + float(v.detach())
            n += 1
        tr = _mean(acc, n)
        acc, n = {}, 0
        for batch in loaders["val"]:                        # ---- validacion (perdida + mIoU)
            with torch.autocast("cuda", dtype=torch.float16, enabled=use_amp):
                losses = model.val_loss(batch)
            for k, v in losses.items():
                acc[k] = acc.get(k, 0.0) + float(v.detach())
            n += 1
        va = _mean(acc, n)
        miou = evaluate(model, loaders["val"], device)["overall"]["IoU"]

        hist["epoch"].append(ep); hist["train_loss"].append(tr["loss"]); hist["val_loss"].append(va["loss"])
        hist["val_mIoU"].append(miou); hist["lr"].append(opt.param_groups[-1]["lr"])
        flag = ""
        if miou > best:
            best, bad, flag = miou, 0, "  <- mejor"
            model.save(weights_path, extra={"epoch": ep, "val_mIoU": miou})
        else:
            bad += 1
        log(f"[{tag}] ep {ep:02d}/{epochs}  train {tr['loss']:.4f}  val {va['loss']:.4f}  "
            f"val mIoU {miou:.4f}  ({time.time() - t0:.0f}s){flag}")
        (OUTPUTS_DIR / f"history_{tag}.json").write_text(json.dumps(hist, indent=2), encoding="utf-8")
        if bad >= patience:
            log(f"[{tag}] sin mejora en {patience} epocas -> early stopping")
            break
    return hist


@torch.no_grad()
def tune_thresholds(model, loader, bins=200):
    """Elige, por clase, el umbral que maximiza el IoU en VALIDACION (el test nunca se usa para elegirlos)."""
    pos = torch.zeros(NUM_CLASSES, bins, dtype=torch.float64)
    neg = torch.zeros(NUM_CLASSES, bins, dtype=torch.float64)
    for batch in loader:
        probs, _ = model.predict(batch["image"], panoptic=False)
        gt = batch["gt"].bool()
        idx = (probs * (bins - 1)).floor().long().clamp(0, bins - 1)
        for c in range(NUM_CLASSES):
            pos[c] += torch.bincount(idx[:, c][gt[:, c]], minlength=bins).double()
            neg[c] += torch.bincount(idx[:, c][~gt[:, c]], minlength=bins).double()
    th = []
    for c in range(NUM_CLASSES):
        tp = pos[c].flip(0).cumsum(0).flip(0)
        fp = neg[c].flip(0).cumsum(0).flip(0)
        fn = pos[c].sum() - tp
        th.append((tp / (tp + fp + fn + 1e-9)).argmax().item() / (bins - 1))
    return th


def test_best(model_cls, loaders, device, tag, weights_path=None, log=print):
    """Carga los mejores pesos y evalua en test real y test sintetico (varias piezas).

    Guarda outputs/metrics_<tag>.json con: umbral 0.5, umbral por clase (elegido en val) y AP50 de piezas.
    """
    weights_path = Path(weights_path or WEIGHTS_DIR / f"{tag}_best.pt")
    model = model_cls.load(weights_path, device)
    th = tune_thresholds(model, loaders["val"])
    out = {"umbrales_por_clase": dict(zip(CLASS_NAMES, th))}
    for split in ("test", "test_sintetico"):
        base = evaluate(model, loaders[split], device, instancias=True)           # umbral 0.5
        tuned = evaluate(model, loaders[split], device, threshold=th)
        out[split] = {"umbral_0.5": base, "umbral_por_clase": tuned, "cumple_minimos": check_targets(tuned["overall"])}
        log(f"[{tag}] {split:15s} (umbral 0.5)  " + "  ".join(f"{k}={v:.4f}" for k, v in base["overall"].items())
            + f"  AP50_piezas={base['instancias']['AP50']:.4f}")
        log(f"[{tag}] {split:15s} (umbral/clase) " + "  ".join(f"{k}={v:.4f}" for k, v in tuned["overall"].items()))
    (OUTPUTS_DIR / f"metrics_{tag}.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    return model, out


def plot_history(tags, out_png=None):
    """Curvas de perdida de entrenamiento y validacion de los modelos (una grafica por modelo)."""
    out_png = Path(out_png or OUTPUTS_DIR / "curvas_perdida.png")
    hs = {t: json.loads((OUTPUTS_DIR / f"history_{t}.json").read_text()) for t in tags}
    fig, axs = plt.subplots(1, len(hs), figsize=(6 * len(hs), 4), squeeze=False)
    for ax, (t, h) in zip(axs[0], hs.items()):
        ax.plot(h["epoch"], h["train_loss"], label="entrenamiento")
        ax.plot(h["epoch"], h["val_loss"], label="validación")
        ax.set_title(t); ax.set_xlabel("época"); ax.set_ylabel("pérdida"); ax.grid(alpha=0.3); ax.legend()
    fig.tight_layout(); fig.savefig(out_png, dpi=150); plt.close(fig)
    return out_png
