"""Tablas y figuras del informe: comparacion de modelos, curvas de perdida, dataset y resultados cualitativos.

Todo se calcula a partir de lo que dejan `train.py` y `evaluar.py` en outputs/ (history_<tag>.json y metrics_<tag>.json),
asi que se puede correr en Colab o en el PC sin volver a entrenar:   python generar_reporte.py
"""
import json
import random
import sys
from pathlib import Path

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import CLASS_COLORS, CLASS_NAMES, OUTPUTS_DIR, ROOT, TARGETS

REPORTE_DIR = OUTPUTS_DIR / "reporte"
METRICAS = ["IoU", "mAP", "F1", "Precisión"]

# Resultados ORIGINALES del Taller 2 (Cartografia Automatizada, imagenes satelitales). Orden: IoU, mAP, F1, Precision.
# Se copian de la tabla de la Parte 3 del Taller 2; NO son comparables con la balsa (otro dataset y otras clases).
TALLER2_ORIGINAL = {
    "EffPS-Lite 512 (mejor modelo del Taller 2)": [0.5423, 0.6672, 0.6899, 0.6523],
    "Mask2Former 256 (Taller 2)": [0.5031, 0.5821, 0.6500, 0.5999],
}

# (modelo, conjunto de prueba, tag de outputs/metrics_<tag>.json, subconjunto)
FILAS = [
    ("EffPS-Lite adaptado (inicio: pesos del Taller 2)", "Balsa, test real", "effps_taller2", "test"),
    ("EffPS-Lite adaptado (inicio: pesos del Taller 2)", "Balsa, test sintético (varias piezas)", "effps_taller2", "test_sintetico"),
    ("Control: misma arquitectura, inicio ImageNet", "Balsa, test real", "effps_imagenet", "test"),
    ("Control: misma arquitectura, inicio ImageNet", "Balsa, test sintético (varias piezas)", "effps_imagenet", "test_sintetico"),
    ("Entrenado sin fotos del iPhone 15 Pro Max", "Solo fotos del iPhone 15 Pro Max (cámara no vista)", "effps_camara", "test"),
    ("Modelo adaptado, antes de usar fotos de la webcam", "Fotos de la webcam, test", "webcam_antes", "test"),
    ("Modelo adaptado + fotos de la webcam (final)", "Fotos de la webcam, test", "webcam_despues", "test"),
    ("Modelo adaptado + fotos de la webcam (final)", "Balsa original + webcam, test real", "effps_webcam", "test"),
]


def cargar_metricas(tag):
    """Lee outputs/metrics_<tag>.json (None si ese experimento no se ha corrido)."""
    p = OUTPUTS_DIR / f"metrics_{tag}.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def tabla_taller2_original():
    """Resultados originales del Taller 2 (otro dataset y otras clases): solo de referencia."""
    df = pd.DataFrame(TALLER2_ORIGINAL, index=METRICAS).T
    df.insert(0, "Conjunto de prueba", "Imágenes satelitales de Bucaramanga (clases del Taller 2)")
    return df


def tabla_comparativa(analisis=None):
    """Tabla del Proyecto de Corte: metricas (umbral 0.5) de cada modelo sobre su conjunto de prueba de balsa.

    analisis: {numero_de_fila: texto}; se escribe en la columna 'Análisis' (la redacta el estudiante).
    """
    analisis = analisis or {}
    filas = []
    for modelo, prueba, tag, split in FILAS:
        m = cargar_metricas(tag)
        if m is None or split not in m:
            continue
        r = m[split]["umbral_0.5"]
        o = r["overall"]
        filas.append({"Modelo": modelo, "Conjunto de prueba": prueba, **{k: o[k] for k in METRICAS},
                      "AP50 piezas": r.get("instancias", {}).get("AP50", np.nan),
                      "¿Cumple mínimos?": "Sí" if all(o[k] >= v for k, v in TARGETS.items()) else "No"})
    df = pd.DataFrame(filas)
    df.index = range(1, len(df) + 1)
    df["Análisis"] = [analisis.get(i, "") for i in df.index]
    return df


def tabla_por_clase(tag, split="test"):
    """IoU, precision, recall, F1 y AP de cada clase (fondo, superficie de trabajo, pieza)."""
    m = cargar_metricas(tag)
    return None if m is None else pd.DataFrame(m[split]["umbral_0.5"]["per_class"]).T


def tabla_diferencias():
    """Diferencias entre pares de modelos (datos numericos para que redactes tu analisis)."""
    pares = [("Taller 2 – ImageNet (test real)", ("effps_taller2", "test"), ("effps_imagenet", "test")),
             ("Taller 2 – ImageNet (test sintético)", ("effps_taller2", "test_sintetico"), ("effps_imagenet", "test_sintetico")),
             ("Webcam final – antes (fotos de la webcam)", ("webcam_despues", "test"), ("webcam_antes", "test")),
             ("Test real – cámara no vista (iPhone 15)", ("effps_taller2", "test"), ("effps_camara", "test"))]
    filas = {}
    for nombre, (ta, sa), (tb, sb) in pares:
        a, b = cargar_metricas(ta), cargar_metricas(tb)
        if a and b:
            oa, ob = a[sa]["umbral_0.5"]["overall"], b[sb]["umbral_0.5"]["overall"]
            filas[nombre] = {k: oa[k] - ob[k] for k in METRICAS}
    return pd.DataFrame(filas).T


NOMBRES_CURVAS = {"effps_taller2": "EffPS-Lite adaptado (inicio Taller 2)", "effps_imagenet": "Control (inicio ImageNet)",
                  "effps_camara": "Sin iPhone 15 (cámara no vista)", "effps_webcam": "Reentrenado con fotos de la webcam"}


def fig_curvas(tags=None, salida=None):
    """Curvas de perdida de entrenamiento y validacion (una grafica por modelo) + mIoU de validacion."""
    tags = [t for t in (tags or NOMBRES_CURVAS) if (OUTPUTS_DIR / f"history_{t}.json").exists()]
    hs = {t: json.loads((OUTPUTS_DIR / f"history_{t}.json").read_text()) for t in tags}
    fig, axs = plt.subplots(2, len(hs), figsize=(4.6 * len(hs), 7), squeeze=False)
    for j, (t, h) in enumerate(hs.items()):
        a = axs[0][j]
        a.plot(h["epoch"], h["train_loss"], label="entrenamiento")
        a.plot(h["epoch"], h["val_loss"], label="validación")
        a.set_title(NOMBRES_CURVAS.get(t, t), fontsize=10); a.set_xlabel("época"); a.set_ylabel("pérdida")
        a.grid(alpha=0.3); a.legend()
        b = axs[1][j]
        b.plot(h["epoch"], h["val_mIoU"], color="tab:green")
        b.set_xlabel("época"); b.set_ylabel("mIoU de validación"); b.grid(alpha=0.3)
    fig.tight_layout()
    REPORTE_DIR.mkdir(parents=True, exist_ok=True)
    salida = Path(salida or REPORTE_DIR / "curvas_perdida.png")
    fig.savefig(salida, dpi=150); plt.close(fig)
    return salida


def resumen_dataset(data_dir):
    """Imagenes y piezas por subconjunto (train/val/test)."""
    data_dir, filas = Path(data_dir), []
    for sp in ("train", "val", "test"):
        imgs = sorted((data_dir / sp / "images").glob("*.jpg"))
        n = [int((np.unique(cv2.imread(str(data_dir / sp / "instances" / f"{p.stem}.png"), cv2.IMREAD_UNCHANGED)) > 0).sum())
             for p in imgs]
        filas.append({"Subconjunto": sp, "Imágenes": len(imgs), "Piezas anotadas": sum(n),
                      "Piezas por imagen (promedio)": round(float(np.mean(n)), 2) if n else 0})
    return pd.DataFrame(filas).set_index("Subconjunto")


PALETA = [(60, 220, 60), (255, 200, 0), (255, 80, 200), (0, 200, 255), (80, 120, 255)]


def fig_dataset(data_dir, salida=None, n=3, semilla=3):
    """Ejemplos del dataset: imagen, mascara semantica (stuff) y mascaras de instancia (cada pieza)."""
    data_dir = Path(data_dir)
    imgs = sorted((data_dir / "train" / "images").glob("*.jpg"))
    sel = random.Random(semilla).sample(imgs, min(n, len(imgs)))
    fig, axs = plt.subplots(len(sel), 3, figsize=(12, 2.4 * len(sel)), squeeze=False)
    for r, p in enumerate(sel):
        img = cv2.cvtColor(cv2.imread(str(p)), cv2.COLOR_BGR2RGB)
        sem = cv2.imread(str(data_dir / "train" / "semantic" / f"{p.stem}.png"), cv2.IMREAD_UNCHANGED)
        ins = cv2.imread(str(data_dir / "train" / "instances" / f"{p.stem}.png"), cv2.IMREAD_UNCHANGED)
        sem_rgb = np.zeros((*sem.shape[:2], 3), np.uint8)
        for k, c in CLASS_COLORS.items():
            sem_rgb[sem == k] = c
        ins_rgb = img.copy()
        for j, i in enumerate(u for u in np.unique(ins) if u > 0):
            ins_rgb[ins == i] = (0.4 * img[ins == i] + 0.6 * np.array(PALETA[j % len(PALETA)])).astype(np.uint8)
        for c, (im, t) in enumerate([(img, "imagen"), (sem_rgb, "semántica (stuff)"), (ins_rgb, "instancias (things)")]):
            axs[r][c].imshow(im); axs[r][c].axis("off")
            if r == 0:
                axs[r][c].set_title(t, fontsize=10)
    handles = [plt.Rectangle((0, 0), 1, 1, color=np.array(c) / 255) for c in CLASS_COLORS.values()]
    fig.legend(handles, CLASS_NAMES, loc="lower center", ncol=3, fontsize=9)
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    REPORTE_DIR.mkdir(parents=True, exist_ok=True)
    salida = Path(salida or REPORTE_DIR / "dataset_anotaciones.png")
    fig.savefig(salida, dpi=130); plt.close(fig)
    return salida


def fig_predicciones(pesos, data_dir, salida, split="test", n=6, semilla=0, escala_px_cm=None):
    """Resultado panoptico del modelo (piezas con largo x ancho + stuff) sobre imagenes de prueba."""
    sys.path.insert(0, str(ROOT))
    from main import piezas_medidas                       # misma medicion que usa la app en tiempo real
    from .inferencia import Segmentador
    from .medidas import Seguidor
    from .visual import dibujar
    modelo = Segmentador(str(pesos))
    imgs = sorted((Path(data_dir) / split / "images").glob("*.jpg"))
    sel = random.Random(semilla).sample(imgs, min(n, len(imgs)))
    cols = 3
    fig, axs = plt.subplots(-(-len(sel) // cols), cols, figsize=(5 * cols, 3 * -(-len(sel) // cols)), squeeze=False)
    for ax in axs.ravel():
        ax.axis("off")
    for ax, p in zip(axs.ravel(), sel):
        frame = cv2.imread(str(p))
        res = modelo.segmentar(frame)
        piezas = Seguidor().actualizar(piezas_medidas(res))
        ax.imshow(cv2.cvtColor(dibujar(frame, res, piezas, escala_px_cm), cv2.COLOR_BGR2RGB))
    fig.tight_layout()
    salida = Path(salida)
    salida.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(salida, dpi=130); plt.close(fig)
    return salida


def guardar_tablas():
    """Guarda las tablas en outputs/reporte (CSV y Excel) para pegarlas en el informe."""
    REPORTE_DIR.mkdir(parents=True, exist_ok=True)
    tabla = tabla_comparativa()
    tabla.to_csv(REPORTE_DIR / "tabla_comparativa.csv", encoding="utf-8-sig")
    with pd.ExcelWriter(REPORTE_DIR / "tablas_informe.xlsx") as xw:
        tabla.to_excel(xw, sheet_name="Comparativa")
        tabla_taller2_original().to_excel(xw, sheet_name="Taller2_original")
        tabla_diferencias().to_excel(xw, sheet_name="Diferencias")
        for tag in ("effps_taller2", "effps_imagenet", "webcam_despues"):
            pc = tabla_por_clase(tag)
            if pc is not None:
                pc.to_excel(xw, sheet_name=f"PorClase_{tag}"[:31])
    return REPORTE_DIR
