"""Metricas: IoU, precision, recall, F1 y mAP por clase (a nivel de pixel) + AP50 de instancias (piezas).

Las metricas de pixel son las mismas del Taller 2 (para poder comparar): el modelo entrega mapas de
probabilidad (B,C,H,W); con un umbral se obtiene la mascara de cada clase y se acumulan TP/FP/FN
sobre TODO el conjunto. mAP = promedio del AP (curva precision-recall) de las clases.
AP50 de instancias: una pieza predicha cuenta como acierto si su IoU con una pieza real es >= 0.5.
"""
import numpy as np
import torch
from torchmetrics.classification import BinaryAveragePrecision

from .config import CLASS_NAMES, NUM_CLASSES, TARGETS


class SegMetrics:
    def __init__(self, threshold=0.5, ap_bins=200, device="cpu"):
        # un solo umbral para todas las clases, o una lista con un umbral por clase
        self.thr = (torch.tensor(threshold, dtype=torch.float32).view(1, -1, 1, 1)
                    if isinstance(threshold, (list, tuple)) else threshold)
        self.tp = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        self.fp = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        self.fn = torch.zeros(NUM_CLASSES, dtype=torch.float64)
        self.ap = [BinaryAveragePrecision(thresholds=ap_bins).to(device) for _ in range(NUM_CLASSES)]

    @torch.no_grad()
    def update(self, probs, gt):
        """probs: (B,C,H,W) float en [0,1]; gt: (B,C,H,W) {0,1}."""
        gt = gt.to(probs.device).bool()
        pred = probs >= self.thr
        for c in range(NUM_CLASSES):
            p, g = pred[:, c], gt[:, c]
            self.tp[c] += (p & g).sum().item()
            self.fp[c] += (p & ~g).sum().item()
            self.fn[c] += (~p & g).sum().item()
            self.ap[c].update(probs[:, c].flatten(), g.flatten().int())

    def compute(self):
        eps = 1e-9
        tp, fp, fn = self.tp, self.fp, self.fn
        iou = tp / (tp + fp + fn + eps)
        prec = tp / (tp + fp + eps)
        rec = tp / (tp + fn + eps)
        f1 = 2 * tp / (2 * tp + fp + fn + eps)
        ap = torch.stack([m.compute().cpu() for m in self.ap]).double()
        per_class = {name: {"IoU": iou[i].item(), "Precisión": prec[i].item(), "Recall": rec[i].item(),
                            "F1": f1[i].item(), "AP": ap[i].item()} for i, name in enumerate(CLASS_NAMES)}
        # Promedio solo sobre las clases que EXISTEN en el conjunto evaluado (con al menos un pixel de referencia).
        # Una clase ausente (p. ej. "Superficie de trabajo" en las fotos de la webcam, donde no hay mesa) no se puede
        # evaluar y contaria como 0, bajando el promedio sin que el modelo haya fallado.
        presentes = ((tp + fn) > 0).nonzero().flatten().tolist() or list(range(NUM_CLASSES))
        overall = {"IoU": iou[presentes].mean().item(), "Precisión": prec[presentes].mean().item(),
                   "Recall": rec[presentes].mean().item(), "F1": f1[presentes].mean().item(),
                   "mAP": ap[presentes].mean().item()}
        return {"overall": overall, "per_class": per_class, "clases_promediadas": [CLASS_NAMES[i] for i in presentes]}


class InstanceAP:
    """AP50 de las piezas (instancias): empareja por IoU de mascara y calcula el area bajo la curva P-R."""

    def __init__(self, iou_thr=0.5):
        self.iou_thr = iou_thr
        self.scores, self.tp, self.n_gt = [], [], 0

    def update(self, pred_masks, pred_scores, gt_masks):
        """pred_masks: lista de (H,W) bool; pred_scores: lista de float; gt_masks: (n,H,W) tensor/array."""
        gt = [np.asarray(m).astype(bool) for m in gt_masks]
        self.n_gt += len(gt)
        usado = [False] * len(gt)
        for k in np.argsort(pred_scores)[::-1]:
            m, best, bj = pred_masks[k], 0.0, -1
            for j, g in enumerate(gt):
                if usado[j]:
                    continue
                iou = (m & g).sum() / max((m | g).sum(), 1)
                if iou > best:
                    best, bj = iou, j
            ok = best >= self.iou_thr
            if ok:
                usado[bj] = True
            self.scores.append(float(pred_scores[k]))
            self.tp.append(1 if ok else 0)

    def compute(self):
        if self.n_gt == 0:
            return {"AP50": float("nan"), "Precisión_inst": float("nan"), "Recall_inst": float("nan"), "F1_inst": float("nan")}
        o = np.argsort(self.scores)[::-1]
        tp = np.array(self.tp)[o]
        ctp, cfp = np.cumsum(tp), np.cumsum(1 - tp)
        rec = ctp / self.n_gt
        prec = ctp / np.maximum(ctp + cfp, 1e-9)
        # AP con interpolacion de todos los puntos
        mrec, mpre = np.concatenate([[0], rec, [1]]), np.concatenate([[0], prec, [0]])
        for i in range(len(mpre) - 2, -1, -1):
            mpre[i] = max(mpre[i], mpre[i + 1])
        idx = np.where(mrec[1:] != mrec[:-1])[0]
        ap = float(((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]).sum())
        p_f, r_f = (prec[-1], rec[-1]) if len(tp) else (0.0, 0.0)   # operando con todas las detecciones (score>=umbral)
        return {"AP50": ap, "Precisión_inst": float(p_f), "Recall_inst": float(r_f),
                "F1_inst": float(2 * p_f * r_f / max(p_f + r_f, 1e-9))}


def check_targets(overall):
    """Compara contra los minimos del enunciado (IoU>=0.7, mAP>=0.6, F1>=0.8)."""
    return {k: bool(overall[k] >= v) for k, v in TARGETS.items()}
