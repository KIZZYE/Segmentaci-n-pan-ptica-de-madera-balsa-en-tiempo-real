"""Dataset de madera balsa: lectura, aumentos, composiciones con varias piezas y DataLoaders."""
import random
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from .composite import extraer_parche, pegar_parches
from .config import IMG_H, IMG_W, MIN_SEGMENT_AREA, NUM_CLASSES, SEED


def listar(split_dir):
    """[(imagen, semantica, instancias)] de un split (carpetas images/ semantic/ instances/)."""
    split_dir = Path(split_dir)
    out = []
    for p in sorted((split_dir / "images").glob("*.jpg")):
        s, i = split_dir / "semantic" / (p.stem + ".png"), split_dir / "instances" / (p.stem + ".png")
        if s.exists() and i.exists():
            out.append((p, s, i))
    if not out:
        raise FileNotFoundError(f"No hay imagenes/mascaras en {split_dir} (esperaba images/, semantic/, instances/).")
    return out


def _leer(img_p, sem_p, inst_p, size):
    """Lee una muestra y la deja a `size`=(alto, ancho): img uint8 (H,W,3), sem uint8 (H,W), inst lista de (H,W)."""
    h, w = size
    img = cv2.resize(cv2.cvtColor(cv2.imread(str(img_p)), cv2.COLOR_BGR2RGB), (w, h), interpolation=cv2.INTER_AREA)
    sem = cv2.resize(cv2.imread(str(sem_p), cv2.IMREAD_GRAYSCALE), (w, h), interpolation=cv2.INTER_NEAREST)
    ins = cv2.resize(cv2.imread(str(inst_p), cv2.IMREAD_GRAYSCALE), (w, h), interpolation=cv2.INTER_NEAREST)
    masks = [(ins == k).astype(np.uint8) for k in np.unique(ins) if k > 0]
    return img, sem, masks


def _aumentar(img, sem, inst, size):
    """Zoom aleatorio (recorte 16:9 reescalado), espejos y color. img (H,W,3) del tamano de cache."""
    H, W = sem.shape
    h, w = size
    f = random.uniform(0.6, 1.0)                                   # fraccion del lado que se conserva
    ch, cw = int(H * f), int(W * f)
    y, x = random.randint(0, H - ch), random.randint(0, W - cw)
    sl = (slice(y, y + ch), slice(x, x + cw))
    img = cv2.resize(img[sl], (w, h), interpolation=cv2.INTER_LINEAR)
    sem = cv2.resize(sem[sl], (w, h), interpolation=cv2.INTER_NEAREST)
    inst = [cv2.resize(m[sl], (w, h), interpolation=cv2.INTER_NEAREST) for m in inst]
    if random.random() < 0.5:                                      # espejo horizontal
        img, sem, inst = img[:, ::-1], sem[:, ::-1], [m[:, ::-1] for m in inst]
    if random.random() < 0.3:                                      # espejo vertical (otros angulos de camara)
        img, sem, inst = img[::-1], sem[::-1], [m[::-1] for m in inst]
    img = img.astype(np.float32) / 255.0
    gray = img.mean(2, keepdims=True)
    img = gray + (img - gray) * random.uniform(0.6, 1.3)           # saturacion (piezas palidas o muy rojizas)
    img = (img - 0.5) * random.uniform(0.75, 1.3) + 0.5 + random.uniform(-0.12, 0.12)   # contraste y brillo
    img = np.clip(img, 0, 1) ** random.uniform(0.75, 1.35)         # gamma
    if random.random() < 0.3:                                      # desenfoque leve (movimiento de camara)
        img = cv2.GaussianBlur(img, (0, 0), random.uniform(0.5, 1.5))
    return np.ascontiguousarray(img), np.ascontiguousarray(sem), [np.ascontiguousarray(m) for m in inst]


class BalsaDataset(Dataset):
    """Devuelve image (3,H,W) float, sem (H,W) long, gt (3,H,W) uint8 e inst_masks (n,H,W) uint8.

    train=True      -> aumentos + composiciones al vuelo (probabilidad `p_multi`).
    n_sintetico>0   -> el dataset es un conjunto FIJO de composiciones (semilla fija) con 2-4 piezas,
                       armado solo con imagenes de este mismo split (test sintetico).
    """

    def __init__(self, split_dir, size=(IMG_H, IMG_W), train=False, p_multi=0.5, n_sintetico=0, seed=SEED):
        self.size, self.train, self.p_multi = size, train, p_multi
        cache = (int(size[0] * 1.5), int(size[1] * 1.5)) if train else size   # cache mayor para hacer zoom
        self.cache = cache
        self.items = [_leer(*t, cache) for t in listar(split_dir)]
        self.parches = []
        if train or n_sintetico:
            for img, _, masks in self.items:
                for m in masks:
                    p = extraer_parche(img, m)
                    if p is not None:
                        self.parches.append(p)
        self.sintetico = []
        if n_sintetico:
            rng = np.random.default_rng(seed)
            for k in range(n_sintetico):
                img, sem, masks = self.items[k % len(self.items)]
                n_extra = int(rng.integers(1, 4))
                img, sem, masks = pegar_parches(img, sem, masks, self.parches, rng, n_extra, min_area=MIN_SEGMENT_AREA)
                self.sintetico.append((img.astype(np.float32) / 255.0, sem, masks))

    def __len__(self):
        return len(self.sintetico) or len(self.items)

    def __getitem__(self, i):
        if self.sintetico:
            img, sem, inst = self.sintetico[i]
        else:
            img, sem, inst = self.items[i]
            if self.train:
                if random.random() < self.p_multi:
                    rng = np.random.default_rng(random.getrandbits(32))
                    img, sem, inst = pegar_parches(img, sem, inst, self.parches, rng, int(rng.integers(1, 4)),
                                                   min_area=int(MIN_SEGMENT_AREA * 2))
                img, sem, inst = _aumentar(img, sem, inst, self.size)
                inst = [m for m in inst if m.sum() >= MIN_SEGMENT_AREA]
            else:
                img = img.astype(np.float32) / 255.0
        sem_t = torch.from_numpy(np.ascontiguousarray(sem)).long()
        gt = torch.stack([(sem_t == c) for c in range(NUM_CLASSES)]).to(torch.uint8)
        h, w = sem.shape
        inst_t = torch.from_numpy(np.stack(inst)) if inst else torch.zeros((0, h, w), dtype=torch.uint8)
        return {"image": torch.from_numpy(img).permute(2, 0, 1).contiguous().float(), "sem": sem_t,
                "gt": gt.contiguous(), "inst_masks": inst_t.to(torch.uint8)}


def collate(batch):
    """Cada imagen tiene un numero distinto de piezas -> las mascaras de instancia quedan como lista."""
    return {"image": torch.stack([b["image"] for b in batch]), "sem": torch.stack([b["sem"] for b in batch]),
            "gt": torch.stack([b["gt"] for b in batch]), "inst_masks": [b["inst_masks"] for b in batch]}


def make_loaders(data_dir, batch_size=8, size=(IMG_H, IMG_W), num_workers=2, p_multi=0.5, n_sintetico=48):
    """train (con aumentos+composiciones), val, test (real) y test_sintetico (varias piezas, fijo)."""
    data_dir = Path(data_dir)
    ds = {
        "train": BalsaDataset(data_dir / "train", size, train=True, p_multi=p_multi),
        "val": BalsaDataset(data_dir / "val", size),
        "test": BalsaDataset(data_dir / "test", size),
        "test_sintetico": BalsaDataset(data_dir / "test", size, n_sintetico=n_sintetico),
    }
    loaders = {
        k: DataLoader(v, batch_size=batch_size, shuffle=(k == "train"), drop_last=(k == "train"),
                      num_workers=num_workers if k == "train" else 0, collate_fn=collate,
                      pin_memory=torch.cuda.is_available(), persistent_workers=(k == "train" and num_workers > 0))
        for k, v in ds.items()
    }
    return ds, loaders
