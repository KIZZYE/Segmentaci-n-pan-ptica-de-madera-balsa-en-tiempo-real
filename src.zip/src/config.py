"""Configuracion comun del proyecto: clases, colores, rutas e hiperparametros base."""
from pathlib import Path

# ---------------------------------------------------------------------------
# Rutas
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data" / "dataset_limpio"      # train/ val/ test/ con images/ semantic/ instances/
OUTPUTS_DIR = ROOT / "outputs"                   # curvas, metricas (json), tabla comparativa, ejemplos
WEIGHTS_DIR = ROOT / "models" / "weights"        # pesos .pt del mejor modelo

# ---------------------------------------------------------------------------
# Clases (los valores coinciden con las mascaras semantic/*.png)
#   0 = fondo, 1 = superficie de trabajo (mesa)  -> "stuff"
#   2 = pieza de balsa                           -> "thing" (una instancia por pieza)
# ---------------------------------------------------------------------------
CLASS_NAMES = ["Fondo", "Superficie de trabajo", "Pieza de balsa"]
NUM_CLASSES = len(CLASS_NAMES)
THING_IDS = [2]
STUFF_IDS = [0, 1]
PIECE_ID = 2

# Colores RGB para visualizacion
CLASS_COLORS = {0: (90, 90, 90), 1: (31, 119, 180), 2: (44, 200, 44)}

# ---------------------------------------------------------------------------
# Hiperparametros por defecto
# ---------------------------------------------------------------------------
IMG_H, IMG_W = 320, 576   # 16:9 y multiplos de 32 (requisito del backbone EfficientNet/FPN)
MIN_SEGMENT_AREA = 150    # px (a IMG_H x IMG_W) minimos para considerar un segmento
SEED = 42

# Minimos pedidos en el enunciado del Proyecto de Corte
TARGETS = {"IoU": 0.7, "mAP": 0.6, "F1": 0.8}
