"""Dibujo del resultado panoptico sobre el fotograma (solo texto ASCII: OpenCV no dibuja tildes)."""
import cv2
import numpy as np

from .config import CLASS_NAMES

NOMBRES = {0: "Fondo", 1: "Superficie de trabajo"}                       # stuff
COLOR_STUFF = {0: (120, 120, 120), 1: (200, 110, 30)}                    # BGR
COLORES_PIEZA = [(60, 220, 60), (0, 200, 255), (255, 80, 200), (255, 200, 0), (80, 120, 255), (200, 255, 120)]


def _texto(img, txt, org, color=(255, 255, 255), escala=0.55):
    (w, h), b = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, escala, 1)
    x, y = org
    cv2.rectangle(img, (x - 2, y - h - 4), (x + w + 2, y + b), (0, 0, 0), -1)
    cv2.putText(img, txt, (x, y), cv2.FONT_HERSHEY_SIMPLEX, escala, color, 1, cv2.LINE_AA)


def dibujar(frame, res, piezas, cm_por_px=None, fps=None, mostrar_stuff=True, fps_modelo=None, mascara=False):
    """frame BGR; res = salida de Segmentador; piezas = medidas con 'num' (Seguidor)."""
    out = frame.copy()
    seg = res["seg"]
    if mostrar_stuff:                                                    # stuff: regiones coloreadas
        capa = out.copy()
        for s in res["segments"]:
            if not s["is_thing"]:
                capa[seg == s["id"]] = COLOR_STUFF[s["label_id"]]
        out = cv2.addWeighted(capa, 0.35, out, 0.65, 0)
        y = 24
        for c, nom in NOMBRES.items():                                   # leyenda de stuff
            cv2.rectangle(out, (10, y - 12), (26, y + 2), COLOR_STUFF[c], -1)
            _texto(out, nom, (32, y), escala=0.5)
            y += 22
    # things: cada pieza con su color, contorno, rectangulo rotado y medidas
    for p in piezas:
        col = COLORES_PIEZA[(p["num"] - 1) % len(COLORES_PIEZA)]
        capa = out.copy()                                                # la pieza se dibuja como rectangulo (es un bloque)
        cv2.fillPoly(capa, [p["caja"]], col)
        if mascara:                                                      # tecla m: ademas, la mascara real del modelo
            capa[seg == p["id"]] = (255, 255, 255)
        out = cv2.addWeighted(capa, 0.35, out, 0.65, 0)
        cv2.polylines(out, [p["caja"]], True, col, 3, cv2.LINE_AA)
        if cm_por_px:
            txt = f"Pieza {p['num']}: {p['largo'] * cm_por_px:.1f} x {p['ancho'] * cm_por_px:.1f} cm"
        else:
            txt = f"Pieza {p['num']}: {p['largo']:.0f} x {p['ancho']:.0f} px"
        cx, cy = int(p["centro"][0]), int(p["centro"][1])
        _texto(out, txt, (max(cx - 90, 4), max(cy, 16)), col)
    estado = f"Piezas: {len(piezas)}   " + ("Medidas: cm" if cm_por_px else "Medidas: px (calibrar con 'c')")
    if fps is not None:
        estado += f"   Video {fps:.0f} FPS" if fps_modelo is not None else f"   {fps:.1f} FPS"
    if fps_modelo is not None:
        estado += f" | Modelo {fps_modelo:.1f} FPS"
    _texto(out, estado, (10, out.shape[0] - 10), (0, 255, 255))
    return out
