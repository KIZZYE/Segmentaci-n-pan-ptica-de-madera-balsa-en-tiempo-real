"""Composiciones copy-paste: pegan piezas de balsa extra sobre una imagen para simular varias piezas.

Las imagenes reales traen una sola pieza; el proyecto pide segmentar varias a la vez. La tecnica
(copy-paste, Ghiasi et al. 2021) recorta piezas con su mascara y las pega en otras posiciones.
Se usa:  (1) al vuelo durante el entrenamiento y  (2) para generar un test sintetico fijo.
Las piezas pegadas SIEMPRE salen del mismo conjunto (train->train, test->test) para no filtrar datos.
"""
import cv2
import numpy as np


def extraer_parche(img, pieza):
    """Recorta la pieza (bbox) y devuelve (rgb uint8, alfa float [0,1]) o None si es muy pequena."""
    ys, xs = np.where(pieza > 0)
    if len(ys) < 200:
        return None
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgb = img[y0:y1, x0:x1].copy()
    alfa = (pieza[y0:y1, x0:x1] > 0).astype(np.float32)
    return rgb, alfa


def _transformar(rgb, alfa, escala, ang):
    """Escala y rota el parche (con bordes expandidos) manteniendo rgb y alfa alineados."""
    h, w = alfa.shape
    M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, escala)
    c, s = abs(M[0, 0]), abs(M[0, 1])
    nw, nh = int(h * s + w * c) + 1, int(h * c + w * s) + 1
    M[0, 2] += nw / 2 - w / 2
    M[1, 2] += nh / 2 - h / 2
    rgb2 = cv2.warpAffine(rgb, M, (nw, nh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    al2 = cv2.warpAffine(alfa, M, (nw, nh), flags=cv2.INTER_LINEAR, borderValue=0)
    return rgb2, al2


def pegar_parches(img, sem, inst, parches, rng, n_extra, max_solape=0.15, min_area=150):
    """Pega hasta `n_extra` piezas nuevas.

    img (H,W,3) uint8, sem (H,W) uint8 {0,1,2}, inst: lista de mascaras (H,W) uint8 (una por pieza),
    parches: lista de (rgb, alfa). Devuelve (img, sem, inst) nuevos; las piezas ya presentes que
    queden tapadas se recortan para que las mascaras no se solapen.
    """
    img, sem, inst = img.copy(), sem.copy(), [m.copy() for m in inst]
    H, W = sem.shape
    ocupado = np.zeros((H, W), bool)
    for m in inst:
        ocupado |= m > 0
    puestas = 0
    for _ in range(n_extra * 6):                     # intentos
        if puestas >= n_extra or not parches:
            break
        rgb, alfa = parches[rng.integers(len(parches))]
        largo = rng.uniform(0.18, 0.5) * W            # lado largo de la pieza en el lienzo
        esc = largo / max(rgb.shape[:2])
        ang = float(rng.choice([0, 90, 180, 270])) + rng.uniform(-8, 8)
        r2, a2 = _transformar(rgb, alfa, esc, ang)
        ph, pw = a2.shape
        if ph >= H or pw >= W or ph < 8 or pw < 8:
            continue
        # brillo/contraste propios del parche (para que no todas las piezas se vean iguales)
        r2 = np.clip(r2.astype(np.float32) * rng.uniform(0.8, 1.2) + rng.uniform(-15, 15), 0, 255).astype(np.uint8)
        a2 = cv2.GaussianBlur(a2, (5, 5), 0)
        nueva_full = np.zeros((H, W), bool)
        for _ in range(15):                           # busca una posicion con poco solape
            y, x = rng.integers(0, H - ph + 1), rng.integers(0, W - pw + 1)
            nueva = a2 > 0.5
            solape = (ocupado[y:y + ph, x:x + pw] & nueva).sum() / max(nueva.sum(), 1)
            if solape <= max_solape:
                break
        else:
            continue
        reg = (slice(y, y + ph), slice(x, x + pw))
        a3 = a2[..., None]
        img[reg] = (a3 * r2 + (1 - a3) * img[reg]).astype(np.uint8)
        nueva_full[reg] = nueva
        inst = [m * (~nueva_full) for m in inst]       # lo que queda tapado deja de ser de la pieza vieja
        inst.append(nueva_full.astype(np.uint8))
        sem[nueva_full] = 2
        ocupado |= nueva_full
        puestas += 1
    inst = [m for m in inst if m.sum() >= min_area]
    return img, sem, inst
