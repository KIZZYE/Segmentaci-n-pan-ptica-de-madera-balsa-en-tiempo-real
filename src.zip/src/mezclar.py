"""Mezcla el dataset de balsa (dataset_limpio) con el de la webcam (dataset_webcam) para reentrenar.

Las fotos de entrenamiento de la webcam se repiten `--rep` veces (cada copia recibe aumentos distintos) para que pesen
frente a las 240 fotos originales. Val y test de la webcam se agregan una sola vez.
    python src/mezclar.py --base data/dataset_limpio --extra data/dataset_webcam --out data/dataset_mixto --rep 4
"""
import argparse
import shutil
from pathlib import Path

SUBS = (("images", ".jpg"), ("semantic", ".png"), ("instances", ".png"))


def copiar(origen, destino, sufijo=""):
    n = 0
    for p in sorted((origen / "images").glob("*.jpg")):
        for sub, ext in SUBS:
            (destino / sub).mkdir(parents=True, exist_ok=True)
            shutil.copy(origen / sub / (p.stem + ext), destino / sub / (p.stem + sufijo + ext))
        n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", required=True)
    ap.add_argument("--extra", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--rep", type=int, default=4)
    a = ap.parse_args()
    base, extra, out = Path(a.base), Path(a.extra), Path(a.out)
    shutil.rmtree(out, ignore_errors=True)
    for sp in ("train", "val", "test"):
        nb = copiar(base / sp, out / sp)
        ne = 0
        for r in range(a.rep if sp == "train" else 1):
            ne += copiar(extra / sp, out / sp, f"_r{r}" if sp == "train" else "")
        print(f"{sp:5s}: {nb} originales + {ne} de la webcam = {nb + ne}")


if __name__ == "__main__":
    main()
