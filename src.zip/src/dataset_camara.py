"""Prueba de generalizacion entre camaras: entrena SIN las fotos del iPhone 15 Pro Max y prueba SOLO con ellas.

    python src/dataset_camara.py --origen data/dataset_limpio --destino data/dataset_camara
Los nombres de archivo del dataset llevan el nombre de la camara; las que contienen --clave van a test.
"""
import argparse
import shutil
from collections import Counter
from pathlib import Path

SUBS = (("images", ".jpg"), ("semantic", ".png"), ("instances", ".png"))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--origen", default="data/dataset_limpio")
    ap.add_argument("--destino", default="data/dataset_camara")
    ap.add_argument("--clave", default="iPhone_15", help="texto del nombre de archivo que identifica la camara de prueba")
    a = ap.parse_args()
    origen, destino = Path(a.origen), Path(a.destino)
    shutil.rmtree(destino, ignore_errors=True)
    cuenta = Counter()
    for sp in ("train", "val", "test"):
        for p in sorted((origen / sp / "images").glob("*.jpg")):
            dst = "test" if a.clave in p.stem else ("val" if sp == "val" else "train")   # la camara de prueba nunca entrena
            for sub, ext in SUBS:
                (destino / dst / sub).mkdir(parents=True, exist_ok=True)
                shutil.copy(origen / sp / sub / (p.stem + ext), destino / dst / sub / (p.stem + ext))
            cuenta[dst] += 1
    print("Imágenes por subconjunto:", dict(cuenta))


if __name__ == "__main__":
    main()
