"""Inferencia en tiempo real: prepara el fotograma, ejecuta EffPS-Lite y devuelve el resultado panoptico."""
import cv2
import numpy as np
import torch

from models.effps_model import EffPS


class Segmentador:
    """Carga los pesos (.pt) y segmenta fotogramas BGR (de cualquier tamano) con la fusion panoptica."""

    def __init__(self, pesos, device=None, score_thr=0.5, hilos=None, escala=1.0):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        if hilos:
            torch.set_num_threads(hilos)
        self.model = EffPS.load(pesos, self.device)
        h0, w0 = self.model.net.img_size               # tamano con el que se entreno (alto, ancho)
        # escala < 1: entrada mas chica (mas FPS, algo menos de precision). Multiplos de 32 para la red.
        self.h, self.w = (max(int(round(h0 * escala / 32)), 1) * 32, max(int(round(w0 * escala / 32)), 1) * 32) if escala != 1.0 else (h0, w0)
        self.model.net.mrcnn.transform.min_size, self.model.net.mrcnn.transform.max_size = (self.h,), self.w
        self.score_thr = score_thr
        # Aceleracion en CPU (no cambia los pesos): pocas propuestas y solo detecciones por encima del umbral,
        # asi la cabeza de cajas/mascaras procesa ~100 regiones en vez de 1000. Las piezas son 1-4 por imagen.
        rpn, roi = self.model.net.mrcnn.rpn, self.model.net.mrcnn.roi_heads
        rpn._pre_nms_top_n = dict(training=2000, testing=300)
        rpn._post_nms_top_n = dict(training=2000, testing=100)
        roi.score_thresh, roi.detections_per_img = max(score_thr, 0.05), 8

    def _preparar(self, frame):
        """Ajusta el fotograma al lienzo del modelo SIN deformarlo (se rellena el borde sobrante)."""
        H, W = frame.shape[:2]
        s = min(self.w / W, self.h / H)
        nw, nh = int(round(W * s)), int(round(H * s))
        chico = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA)
        lienzo = cv2.copyMakeBorder(chico, 0, self.h - nh, 0, self.w - nw, cv2.BORDER_REPLICATE)
        x = torch.from_numpy(cv2.cvtColor(lienzo, cv2.COLOR_BGR2RGB)).permute(2, 0, 1).float()[None] / 255.0
        return x, nw, nh

    @torch.no_grad()
    def segmentar(self, frame):
        """Devuelve {'seg': mapa de ids (H,W) uint8, 'segments': [{id,label_id,score,is_thing}]} al tamano del fotograma."""
        H, W = frame.shape[:2]
        x, nw, nh = self._preparar(frame)
        _, pans = self.model.predict(x, panoptic=True, score_thr=self.score_thr)
        pan = pans[0]
        seg = pan["seg"][:nh, :nw].astype(np.uint8)                       # quita el borde de relleno
        seg = cv2.resize(seg, (W, H), interpolation=cv2.INTER_NEAREST)    # de vuelta al tamano original
        segs = [{k: v for k, v in s.items() if k != "mask"} for s in pan["segments"]]
        return {"seg": seg, "segments": segs}
