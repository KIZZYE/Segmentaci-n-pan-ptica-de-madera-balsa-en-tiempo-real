"""Etiqueta fotos nuevas con SAM a partir de CAJAS dibujadas sobre cada pieza (data/cajas_webcam.json).

Cada caja [x1, y1, x2, y2] (pixeles de la foto original) le dice a SAM cual objeto segmentar; SAM devuelve
la mascara exacta de la pieza. Todo lo que no es pieza queda como "Fondo" (en estas escenas no hay mesa de trabajo).
SAM se usa SOLO para anotar; no forma parte del modelo entregado.

Salida (misma estructura que data/dataset_limpio):
    <out>/{train,val,test}/{images,semantic,instances}   + <out>/review/hoja_XX.jpg (para revisar las mascaras)

Las fotos 4:3 (webcam 640x480) se rellenan a 16:9 repitiendo el borde, igual que hace la app al inferir.
Ejemplo (Colab):  python src/prelabel_cajas.py --fotos /content/fotos_multi --cajas data/cajas_webcam.json --out data/dataset_webcam
"""
import argparse
import json
import os
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi


class SamCajas:
    """SAM (ultralytics) con una caja como indicacion. Con --sin-sam usa la caja como mascara (solo para pruebas)."""

    def __init__(self, pesos="sam_b.pt", device=None, sin_sam=False):
        self.sin_sam = sin_sam
        self.device = device
        if not sin_sam:
            from ultralytics import SAM
            self.m = SAM(pesos)

    def mascara(self, img, caja):
        h, w = img.shape[:2]
        x1, y1, x2, y2 = [int(round(v)) for v in caja]
        if self.sin_sam:
            mk = np.zeros((h, w), np.uint8)
            mk[max(y1, 0):y2, max(x1, 0):x2] = 1
            return mk
        r = self.m(img, bboxes=[[x1, y1, x2, y2]], verbose=False, device=self.device)[0]
        if r.masks is None:
            return np.zeros((h, w), np.uint8)
        mk = (r.masks.data[0].cpu().numpy() > 0.5).astype(np.uint8)
        if mk.shape != (h, w):
            mk = cv2.resize(mk, (w, h), interpolation=cv2.INTER_NEAREST)
        return mk


def limpiar(mk):
    """Deja solo el componente mas grande y rellena huecos (una pieza = una region compacta)."""
    n, lab, st, _ = cv2.connectedComponentsWithStats(mk.astype(np.uint8))
    if n <= 1:
        return mk.astype(np.uint8)
    mayor = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    return ndi.binary_fill_holes(lab == mayor).astype(np.uint8)


def a_16x9(arr, es_imagen):
    """Rellena a la derecha hasta 16:9 (imagen: repite el borde; mascara: ceros)."""
    h, w = arr.shape[:2]
    ancho = int(np.ceil(h * 16 / 9))
    if w >= ancho:
        return arr
    if es_imagen:
        return cv2.copyMakeBorder(arr, 0, 0, 0, ancho - w, cv2.BORDER_REPLICATE)
    return cv2.copyMakeBorder(arr, 0, 0, 0, ancho - w, cv2.BORDER_CONSTANT, value=0)


def etiquetar(img, cajas, sam):
    """Devuelve (semantica 0/2, instancias 1..k, banderas) para una foto."""
    masks = [limpiar(sam.mascara(img, c)) for c in cajas]
    orden = sorted(range(len(masks)), key=lambda i: masks[i].sum())     # las pequenas reclaman primero (solapes)
    sem = np.zeros(img.shape[:2], np.uint8)
    ins = np.zeros(img.shape[:2], np.uint8)
    banderas = []
    ocupado = np.zeros(img.shape[:2], bool)
    for k, i in enumerate(orden, 1):
        mk = (masks[i] > 0) & ~ocupado
        x1, y1, x2, y2 = cajas[i]
        if mk.sum() < 0.25 * max((x2 - x1) * (y2 - y1), 1):
            banderas.append(f"mascara_pequena_{i}")
        if mk.sum() > 1.6 * max((x2 - x1) * (y2 - y1), 1):
            banderas.append(f"mascara_grande_{i}")
        ins[mk] = k
        sem[mk] = 2
        ocupado |= mk
    return sem, ins, banderas


def repartir(nombres, frac=0.15):
    """Bloques de fotos consecutivas (evita cuadros casi iguales entre train y test)."""
    n = len(nombres)
    k = max(1, round(n * frac))
    return {"train": nombres[:n - 2 * k], "val": nombres[n - 2 * k:n - k], "test": nombres[n - k:]}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fotos", required=True, help="carpeta con las fotos")
    ap.add_argument("--cajas", default="data/cajas_webcam.json")
    ap.add_argument("--out", default="data/dataset_webcam")
    ap.add_argument("--pesos", default="sam_b.pt")
    ap.add_argument("--device", default=None)
    ap.add_argument("--sin-sam", action="store_true", help="solo pruebas: usa la caja como mascara")
    a = ap.parse_args()

    cajas = json.load(open(a.cajas))
    nombres = sorted(n for n in cajas if (Path(a.fotos) / n).exists())
    faltan = sorted(set(cajas) - set(nombres))
    if faltan:
        print("Aviso: no estan en la carpeta de fotos:", faltan[:5])
    sam = SamCajas(a.pesos, a.device, a.sin_sam)
    reparto = repartir(nombres)
    out = Path(a.out)
    for sp in reparto:
        for sub in ("images", "semantic", "instances"):
            (out / sp / sub).mkdir(parents=True, exist_ok=True)
    (out / "review").mkdir(parents=True, exist_ok=True)
    tiles, marcadas = [], 0
    for sp, lista in reparto.items():
        for n in lista:
            img = cv2.imread(str(Path(a.fotos) / n))
            sem, ins, ban = etiquetar(img, cajas[n], sam)
            img16, sem16, ins16 = a_16x9(img, True), a_16x9(sem, False), a_16x9(ins, False)
            st = Path(n).stem
            cv2.imwrite(str(out / sp / "images" / f"{st}.jpg"), img16, [cv2.IMWRITE_JPEG_QUALITY, 95])
            cv2.imwrite(str(out / sp / "semantic" / f"{st}.png"), sem16)
            cv2.imwrite(str(out / sp / "instances" / f"{st}.png"), ins16)
            ov = img16.copy()
            ov[sem16 == 2] = (0.5 * ov[sem16 == 2] + 0.5 * np.array([0, 255, 0])).astype(np.uint8)
            for k in range(1, int(ins16.max()) + 1):
                cs, _ = cv2.findContours((ins16 == k).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(ov, cs, -1, (0, 0, 255) if ban else (255, 255, 0), 2)
            cv2.putText(ov, f"{st[-4:]} {sp} {' '.join(ban)}", (8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
            tiles.append(cv2.resize(ov, (480, 270)))
            marcadas += bool(ban)
    while len(tiles) % 12:
        tiles.append(np.zeros_like(tiles[0]))
    for k in range(0, len(tiles), 12):
        hoja = np.vstack([np.hstack(tiles[k + i:k + i + 4]) for i in (0, 4, 8)])
        cv2.imwrite(str(out / "review" / f"hoja_{k // 12:02d}.jpg"), hoja, [cv2.IMWRITE_JPEG_QUALITY, 88])
    print({sp: len(v) for sp, v in reparto.items()}, f"| {marcadas} fotos con banderas | hojas en {out / 'review'}")


if __name__ == "__main__":
    main()
