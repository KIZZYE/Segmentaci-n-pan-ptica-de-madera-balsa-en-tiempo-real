"""Compensacion de movimiento: mantiene el contorno pegado a la pieza mientras llega el siguiente resultado del modelo.

El modelo tarda ~0.3-0.5 s por resultado en CPU. En ese tiempo la mano mueve la madera, asi que el resultado
llega "viejo". Aqui se mide cuanto se movio cada pieza desde el fotograma que se segmento (flujo optico de
Farneback a baja resolucion, ~5 ms) y se desplaza su mascara y su caja esa misma distancia.
"""
import cv2
import numpy as np


class Compensador:
    def __init__(self, ancho=224):
        self.ancho, self.g0, self.res, self.piezas, self.s = ancho, None, None, [], 1.0

    def _gris(self, frame):
        h, w = frame.shape[:2]
        s = self.ancho / w
        chico = cv2.resize(frame, (self.ancho, max(int(h * s), 1)), interpolation=cv2.INTER_AREA)
        return cv2.cvtColor(chico, cv2.COLOR_BGR2GRAY), s

    def fijar(self, frame_origen, res, piezas):
        """Guarda el resultado del modelo junto con el fotograma sobre el que se calculo."""
        self.g0, self.s = self._gris(frame_origen)
        self.res, self.piezas = res, piezas

    def aplicar(self, frame):
        """Devuelve (res, piezas) desplazados para coincidir con el fotograma actual."""
        res, seg = self.res, self.res["seg"]
        if not self.piezas:
            return res, self.piezas
        g1, _ = self._gris(frame)
        flujo = cv2.calcOpticalFlowFarneback(self.g0, g1, None, 0.5, 4, 21, 3, 5, 1.1, 0)
        H, W = seg.shape
        sup = next((s["id"] for s in res["segments"] if not s["is_thing"] and s["label_id"] == 1), 0)
        nueva, salida = seg.copy(), []
        mascaras = [(p, seg == p["id"]) for p in self.piezas]
        for _, m in mascaras:                                   # donde estaba la pieza queda superficie
            nueva[m] = sup
        for p, m in mascaras:
            ms = cv2.resize(m.astype(np.uint8), (flujo.shape[1], flujo.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
            if ms.sum() >= 5:                                   # movimiento tipico (mediana) de los pixeles de la pieza
                dx, dy = (float(np.median(flujo[..., 0][ms])) / self.s, float(np.median(flujo[..., 1][ms])) / self.s)
            else:
                dx = dy = 0.0
            M = np.float32([[1, 0, dx], [0, 1, dy]])
            nueva[cv2.warpAffine(m.astype(np.uint8), M, (W, H), flags=cv2.INTER_NEAREST) > 0] = p["id"]
            q = dict(p)
            q["centro"] = (p["centro"][0] + dx, p["centro"][1] + dy)
            q["caja"] = np.round(p["caja"] + [dx, dy]).astype(np.int32)
            q["contorno"] = np.round(p["contorno"] + [dx, dy]).astype(np.int32)
            salida.append(q)
        return {"seg": nueva, "segments": res["segments"]}, salida
