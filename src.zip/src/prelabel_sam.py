"""Pre-etiquetado panoptico de madera balsa con SAM (Segment Anything).

Para cada imagen genera:
  * semantic/<id>.png   -> 0 = fondo, 1 = superficie_trabajo (stuff), 2 = pieza_balsa (thing)
  * instances/<id>.png  -> 0 = nada, 1..N = id de cada pieza de balsa (instancias)
  * images/<id>.jpg     -> copia de la imagen
  * meta.csv            -> banderas de calidad (para revisar a mano lo dudoso)
  * review/hoja_XX.jpg  -> hojas de contacto con la mascara superpuesta

Fuentes:
  * capturas/*.jpg (sin etiquetar): la pieza sale de SAM, guiado por puntos semilla de color.
  * dataset_balsa/iphone11 (ya etiquetadas): se usa la mascara existente de la pieza.
  En ambos casos mesa/fondo salen de SAM "segmentar todo" + una regla de contacto con la pieza.

Uso (Colab con GPU o PC local):
  python src/prelabel_sam.py --balsa BALSA --out data/prelabel --paso 4
"""
import argparse
import csv
import glob
import os

import cv2
import numpy as np

CLASES = {0: "fondo", 1: "superficie_trabajo", 2: "pieza_balsa"}


# --------------------------------------------------------------------------
# 1) Semillas por color: dan a SAM un punto dentro de la pieza (y otros fuera)
# --------------------------------------------------------------------------
def mascara_color(img):
    """Mascara aproximada de la balsa por tono beige/anaranjado (solo para sembrar puntos)."""
    h, s, v = cv2.split(cv2.cvtColor(img, cv2.COLOR_BGR2HSV))
    m = ((h >= 8) & (h <= 28) & (s >= 35) & (s <= 170) & (v >= 110)).astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((25, 25), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n <= 1:
        return np.zeros_like(m)
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))  # componente mas grande
    return ((lab == i) * 255).astype(np.uint8)


def semillas_color(img, n_pos=4, n_neg=2, seed=0):
    """Devuelve (puntos_positivos, puntos_negativos, mascara_color) o None si no hay candidato."""
    rng = np.random.default_rng(seed)
    m = mascara_color(img)
    h, w = m.shape
    if (m > 0).sum() < 0.002 * h * w:
        return None
    dist = cv2.distanceTransform(m, cv2.DIST_L2, 5)
    d = dist.copy()
    pos = []
    for _ in range(n_pos):  # puntos bien adentro de la region, separados entre si
        y, x = np.unravel_index(int(np.argmax(d)), d.shape)
        if d[y, x] < 3:
            break
        pos.append([int(x), int(y)])
        cv2.circle(d, (int(x), int(y)), int(max(dist[y, x] * 1.5, 10)), 0, -1)
    # negativos: pixeles muy oscuros (mesa) lejos de la pieza
    v = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)[..., 2]
    lejos = cv2.dilate(m, np.ones((81, 81), np.uint8)) == 0
    cand = np.argwhere((v < 60) & lejos)
    neg = []
    if len(cand):
        for i in rng.choice(len(cand), size=min(n_neg, len(cand)), replace=False):
            y, x = cand[i]
            neg.append([int(x), int(y)])
    return pos, neg, m


# --------------------------------------------------------------------------
# 2) Backend SAM (ultralytics). Se puede reemplazar en pruebas por uno falso.
# --------------------------------------------------------------------------
class SamUltralytics:
    def __init__(self, pesos="sam_b.pt", device=None):
        from ultralytics import SAM  # pip install ultralytics
        self.m = SAM(pesos)
        self.device = device

    @staticmethod
    def _ajustar(mk, shape):
        mk = (mk > 0.5).astype(np.uint8)
        if mk.shape != shape:
            mk = cv2.resize(mk, (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST)
        return mk

    def mascara_con_puntos(self, img, pos, neg):
        """Una mascara para un objeto dado por puntos positivos (1) y negativos (0)."""
        puntos = [pos + neg]
        etiquetas = [[1] * len(pos) + [0] * len(neg)]
        r = self.m(img, points=puntos, labels=etiquetas, verbose=False, device=self.device)[0]
        if r.masks is None:
            return None
        return self._ajustar(r.masks.data[0].cpu().numpy(), img.shape[:2])

    def todas_las_mascaras(self, img):
        """SAM 'segmentar todo': lista de mascaras binarias."""
        r = self.m(img, verbose=False, device=self.device)[0]
        if r.masks is None:
            return []
        return [self._ajustar(mk.cpu().numpy(), img.shape[:2]) for mk in r.masks.data]


# --------------------------------------------------------------------------
# 3) Reglas: calidad de la pieza y asignacion de la superficie de trabajo
# --------------------------------------------------------------------------
def limpiar(mask, min_frac=0.001):
    """Quita componentes pequenos."""
    mask = (mask > 0).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask)
    out = np.zeros_like(mask)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= min_frac * mask.size:
            out[lab == i] = 1
    return out


def solidez(mask):
    cs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cs:
        return 0.0
    c = max(cs, key=cv2.contourArea)
    hull = cv2.contourArea(cv2.convexHull(c))
    return float(cv2.contourArea(c) / hull) if hull > 0 else 0.0


def banderas_pieza(pieza, color):
    """Metricas simples para marcar lo que hay que revisar a mano."""
    frac = float((pieza > 0).mean())
    cont = float(((pieza > 0) & (color > 0)).sum() / max((color > 0).sum(), 1)) if color is not None else 1.0
    sol = solidez(pieza)
    f = []
    if not 0.005 <= frac <= 0.6:
        f.append("area")
    if cont < 0.6:
        f.append("contencion")
    if sol < 0.85:
        f.append("solidez")
    return frac, cont, sol, f


def asignar_mesa(masks, pieza, img):
    """Elige la region SAM que mas toca a la pieza (y es mas oscura) como superficie de trabajo."""
    h, w = pieza.shape
    anillo = (cv2.dilate(pieza, np.ones((41, 41), np.uint8)) > 0) & (pieza == 0)
    if anillo.sum() == 0:
        return np.zeros_like(pieza)
    v = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)[..., 2]
    mejor, mejor_s = None, 0.0
    for mk in masks:
        mk = mk.astype(bool)
        a = mk.sum()
        if a < 0.04 * h * w:
            continue
        if (mk & (pieza > 0)).sum() / a > 0.3:  # es la propia pieza (o la contiene)
            continue
        contacto = (mk & anillo).sum() / anillo.sum()
        if contacto < 0.10:
            continue
        oscuro = 1 - float(v[mk].mean()) / 255
        s = contacto * (0.5 + 0.5 * oscuro)
        if s > mejor_s:
            mejor, mejor_s = mk, s
    if mejor is None:
        return np.zeros_like(pieza)
    return (mejor & (pieza == 0)).astype(np.uint8)


# --------------------------------------------------------------------------
# 4) Flujo principal
# --------------------------------------------------------------------------
def listar(balsa, paso):
    items = []
    for p in sorted(glob.glob(os.path.join(balsa, "capturas", "*.jpg")))[::paso]:
        items.append(("cap", p, None))
    d = os.path.join(balsa, "dataset_balsa", "iphone11")
    for p in sorted(glob.glob(os.path.join(d, "imagenes", "*.jpg"))):
        stem = os.path.splitext(os.path.basename(p))[0]
        mp = os.path.join(d, "mascaras", stem + ".png")
        if os.path.exists(mp):
            items.append(("etq", p, mp))
    return items


def guardar(out, uid, img, pieza, mesa):
    sem = np.zeros(pieza.shape, np.uint8)
    sem[mesa > 0] = 1
    sem[pieza > 0] = 2
    n, lab = cv2.connectedComponents(pieza)  # una instancia por pieza (componente conexa)
    ins = lab.astype(np.uint8)
    for sub, arr in (("semantic", sem), ("instances", ins)):
        cv2.imwrite(os.path.join(out, sub, uid + ".png"), arr)
    cv2.imwrite(os.path.join(out, "images", uid + ".jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 95])
    return sem


def ejecutar(balsa, out, backend, paso=4, limite=None):
    for sub in ("images", "semantic", "instances", "review"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    meta_path = os.path.join(out, "meta.csv")
    hechos = set()
    if os.path.exists(meta_path):  # reanudar si Colab se desconecto
        hechos = {r["id"] for r in csv.DictReader(open(meta_path, encoding="utf-8"))}
    nuevo = not os.path.exists(meta_path)
    f = open(meta_path, "a", newline="", encoding="utf-8")
    w = csv.writer(f)
    if nuevo:
        w.writerow(["id", "fuente", "area_pieza", "contencion", "solidez", "banderas"])
    items = listar(balsa, paso)[:limite]
    print(f"{len(items)} imagenes por procesar ({len(hechos)} ya hechas)")
    for k, (fuente, ip, mp) in enumerate(items):
        uid = fuente + "_" + os.path.splitext(os.path.basename(ip))[0]
        if uid in hechos:
            continue
        img = cv2.imread(ip)
        if fuente == "etq":
            pieza = (cv2.imread(mp, cv2.IMREAD_GRAYSCALE) > 127).astype(np.uint8)
            if pieza.sum() == 0:  # fotos negativas (sin pieza): se omiten por ahora
                continue
            frac, cont, sol, fl = banderas_pieza(pieza, None)
        else:
            sm = semillas_color(img)
            if sm is None:
                w.writerow([uid, fuente, 0, 0, 0, "sin_semillas"]); f.flush()
                continue
            pos, neg, color = sm
            s = backend.mascara_con_puntos(img, pos, neg)
            if s is None:
                w.writerow([uid, fuente, 0, 0, 0, "sam_vacio"]); f.flush()
                continue
            pieza = limpiar(s)
            frac, cont, sol, fl = banderas_pieza(pieza, color)
        mesa = asignar_mesa(backend.todas_las_mascaras(img), pieza, img)
        if mesa.sum() == 0:
            fl.append("sin_mesa")
        guardar(out, uid, img, pieza, mesa)
        w.writerow([uid, fuente, f"{frac:.4f}", f"{cont:.3f}", f"{sol:.3f}", "|".join(fl)])
        f.flush()
        if (k + 1) % 20 == 0:
            print(f"  {k + 1}/{len(items)}")
    f.close()
    hojas_contacto(out)


def hojas_contacto(out, por_hoja=12):
    """Hojas con la mascara superpuesta (azul = superficie, verde = pieza; borde rojo = revisar)."""
    filas = list(csv.DictReader(open(os.path.join(out, "meta.csv"), encoding="utf-8")))
    filas = [r for r in filas if os.path.exists(os.path.join(out, "semantic", r["id"] + ".png"))]
    # primero las dudosas, para revisarlas con prioridad
    filas.sort(key=lambda r: (r["banderas"] == "", r["id"]))
    tw, th = 360, 203
    for n in range(0, len(filas), por_hoja):
        hoja = np.zeros((th * 3, tw * 4, 3), np.uint8)
        for j, r in enumerate(filas[n:n + por_hoja]):
            img = cv2.imread(os.path.join(out, "images", r["id"] + ".jpg"))
            sem = cv2.imread(os.path.join(out, "semantic", r["id"] + ".png"), cv2.IMREAD_GRAYSCALE)
            ov = img.copy()
            for c, col in ((1, (255, 0, 0)), (2, (0, 255, 0))):
                ov[sem == c] = (0.5 * ov[sem == c] + 0.5 * np.array(col)).astype(np.uint8)
            t = cv2.resize(ov, (tw, th))
            if r["banderas"]:
                cv2.rectangle(t, (0, 0), (tw - 1, th - 1), (0, 0, 255), 4)
            cv2.putText(t, r["id"][-22:] + " " + r["banderas"], (4, th - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            hoja[(j // 4) * th:(j // 4 + 1) * th, (j % 4) * tw:(j % 4 + 1) * tw] = t
        cv2.imwrite(os.path.join(out, "review", f"hoja_{n // por_hoja:02d}.jpg"), hoja)
    print(f"{len(filas)} imagenes, {sum(1 for r in filas if r['banderas'])} marcadas para revisar")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--balsa", default="BALSA", help="carpeta BALSA descomprimida")
    ap.add_argument("--out", default="data/prelabel")
    ap.add_argument("--paso", type=int, default=4, help="tomar 1 de cada N capturas (evita cuadros casi iguales)")
    ap.add_argument("--pesos", default="sam_b.pt", help="sam_b.pt, mobile_sam.pt, sam2_b.pt ...")
    ap.add_argument("--device", default=None, help="'cuda', 'cpu' o vacio (automatico)")
    ap.add_argument("--limite", type=int, default=None)
    a = ap.parse_args()
    ejecutar(a.balsa, a.out, SamUltralytics(a.pesos, a.device), a.paso, a.limite)
