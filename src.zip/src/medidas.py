"""Medidas de cada pieza (largo y ancho), seguimiento entre fotogramas y calibracion px -> cm."""
import json
from pathlib import Path

import cv2
import numpy as np

CALIB_PATH = Path(__file__).resolve().parent.parent / "calibracion.json"
ZONA_PATH = Path(__file__).resolve().parent.parent / "zona.json"


def _rect(mascara):
    cs, _ = cv2.findContours(mascara.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return (max(cs, key=cv2.contourArea), None) if cs else (None, None)


def medir(mascara):
    """Largo y ancho (en pixeles) de una pieza: lados del rectangulo rotado minimo que la envuelve.

    Las piezas de balsa son bloques rectangulares, pero la mascara del modelo puede traer rebabas (dedos, sombras,
    bordes dentados). Por eso se limpia: apertura morfologica (quita lo delgado) y casco convexo, y se mide
    el rectangulo minimo sobre esa forma limpia."""
    m = mascara.astype(np.uint8)
    c, _ = _rect(m)
    if c is None:
        return None
    lado = min(cv2.minAreaRect(c)[1])
    k = int(0.18 * lado) | 1                                   # nucleo impar, ~18% del lado corto
    if k >= 5:
        limpia = cv2.morphologyEx(m, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        c2, _ = _rect(limpia)
        if c2 is not None and cv2.contourArea(c2) > 0.5 * cv2.contourArea(c):
            c = c2
    area = cv2.contourArea(c)
    c = cv2.convexHull(c)
    (cx, cy), (w, h), ang = cv2.minAreaRect(c)
    return {"relleno": area / max(w * h, 1.0), "centro": (cx, cy), "largo": max(w, h), "ancho": min(w, h),
            "caja": cv2.boxPoints(((cx, cy), (w, h), ang)).astype(np.int32), "contorno": c}


class Seguidor:
    """Da a cada pieza un numero estable entre fotogramas (vecino mas cercano) y suaviza sus medidas."""

    def __init__(self, dist_max=150, suavizado=0.35, olvido=20):
        self.pistas, self.sig, self.t = {}, 1, 0
        self.dist_max, self.a, self.olvido = dist_max, suavizado, olvido

    def actualizar(self, piezas):
        """piezas: lista de dicts de `medir` (se les agrega 'num' y se suavizan 'largo' y 'ancho')."""
        self.t += 1
        libres = set(self.pistas)
        for p in sorted(piezas, key=lambda q: -q["largo"] * q["ancho"]):
            mejor, dmin = None, self.dist_max
            for k in libres:
                d = np.hypot(p["centro"][0] - self.pistas[k]["centro"][0], p["centro"][1] - self.pistas[k]["centro"][1])
                if d < dmin:
                    mejor, dmin = k, d
            if mejor is None:
                mejor = self.sig
                self.sig += 1
                self.pistas[mejor] = {"largo": p["largo"], "ancho": p["ancho"]}
            else:
                libres.discard(mejor)
                for k in ("largo", "ancho"):
                    self.pistas[mejor][k] = (1 - self.a) * self.pistas[mejor][k] + self.a * p[k]
            self.pistas[mejor].update(centro=p["centro"], visto=self.t)
            p["num"], p["largo"], p["ancho"] = mejor, self.pistas[mejor]["largo"], self.pistas[mejor]["ancho"]
        for k in [k for k, v in self.pistas.items() if self.t - v["visto"] > self.olvido]:
            del self.pistas[k]
        return sorted(piezas, key=lambda q: q["num"])


def cargar_calibracion():
    """cm por pixel guardado, o None si aun no se calibra."""
    try:
        return float(json.loads(CALIB_PATH.read_text())["cm_por_px"])
    except (OSError, KeyError, ValueError):
        return None


def guardar_calibracion(cm_por_px):
    CALIB_PATH.write_text(json.dumps({"cm_por_px": cm_por_px}, indent=2))


def cargar_zona():
    """Zona de trabajo (x0, y0, x1, y1) en fraccion del fotograma, o None."""
    try:
        return tuple(json.loads(ZONA_PATH.read_text())["zona"])
    except (OSError, KeyError, ValueError):
        return None


def guardar_zona(zona):
    if zona is None:
        ZONA_PATH.unlink(missing_ok=True)
    else:
        ZONA_PATH.write_text(json.dumps({"zona": list(zona)}))
