"""Prueba del flujo SIN SAM real: backend falso (convex hull del color + k-means) para validar archivos, banderas y hojas."""
import sys, numpy as np, cv2
sys.path.insert(0, "src")
import prelabel_sam as P

class Falso:
    def mascara_con_puntos(self, img, pos, neg):
        m = P.mascara_color(img)
        cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = np.zeros_like(m)
        if cs:
            cv2.fillPoly(out, [cv2.convexHull(max(cs, key=cv2.contourArea))], 1)
        return out
    def todas_las_mascaras(self, img):
        sm = cv2.resize(img, (160, 90)); z = cv2.cvtColor(sm, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)
        _, lab, _ = cv2.kmeans(z, 4, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1), 2, cv2.KMEANS_PP_CENTERS)
        lab = lab.reshape(90, 160).astype(np.uint8)
        return [cv2.resize((lab == k).astype(np.uint8), (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST) for k in range(4)]

P.ejecutar("/home/claude/balsa_in/ex/BALSA", "/home/claude/work/prelabel_test", Falso(), paso=200)
